# Non-functional requirements

Values marked TBD require measurement during the prototype. Do not guess
them into a design review — an unmeasured volume assumption is how capacity
problems reach production.

## Volume and capacity

| Parameter | Value | Source |
|---|---|---|
| Assets under management | TBD | Scanner consoles |
| Findings, total active | TBD | Prototype measurement |
| Findings ingested per cycle | TBD | Prototype measurement |
| Logical services | TBD | Tag inventory |
| GitHub issues at steady state | TBD | Derived: services × distinct CVEs |
| Growth headroom | 3× current | Design assumption |

The issue count matters more than it appears. One issue per service × CVE
is a substantial reduction on per-instance, but the first run against an
existing backlog will still be the largest write burst the system ever
produces. Size the rate guard for that, not for steady state.

## Performance

| Requirement | Target |
|---|---|
| Ingest cycle completes within | 30 min |
| Reconciler completes within | 10 min |
| Sync cycle completes within | 10 min |
| Triage UI response, filtered view | < 3 s at full volume |
| Bulk operation, 500 findings | < 60 s |
| Issue state latency (GitHub → UVM) | ≤ 15 min, by design |

The 15-minute latency is a deliberate consequence of polling rather than
webhooks. If a stakeholder objects, the trade is: near-real-time sync
requires an inbound internet-facing endpoint.

## Availability

This is a security operations tool, not a transaction system. Sizing
accordingly:

| Requirement | Target |
|---|---|
| Service availability | Business hours, best effort out of hours |
| Maximum tolerable outage | 24 h without material impact |
| Recovery time objective | 4 h |
| Recovery point objective | 24 h |

**Constraint:** an outage must never cause data loss that manifests as
false remediation. On recovery, the system must resume from its last known
state, not from empty. This is more important than uptime.

## Data retention

| Data | Retention |
|---|---|
| Active findings | Indefinite while active |
| Closed findings | Minimum 24 months |
| Audit log | Minimum 24 months, archived beyond |
| Assessment log | Minimum 12 months |
| Scan artefacts | 90 days |

Retention on closed findings and audit is driven by evidencing control
operation over an audit period, not by operational need.

## Security

- No inbound path from the public internet
- Egress restricted to three named destinations
- Per-component database roles; reporting is read-only
- Secrets in a managed store, never in source or images
- All access authenticated via the corporate identity provider once past POC
- Audit log immutable to application roles

## Observability

Every failure mode must be detectable without a human noticing absence.
Specifically alertable: ingest failure, held submission, staleness breach,
sync failure, rate-limit exhaustion, reconciler failure, and any run
producing zero findings where the previous run produced many.

That last one is the canary. A silent transition to zero is the shape of
every serious failure this system can have.

## Constraints

- Runs within existing cloud tenancy and network design
- No new vendor contract required for the minimum build
- Must not require changes to scanner configuration
- Must not require developers to adopt a new tool — GitHub Issues only
