# UVM — engineering delivery pack

Documents for a team building the Unified Vulnerability Management layer.
Assumes familiarity with the design; see the context brief in the handoff
pack for background.

| File | Purpose | Audience |
|---|---|---|
| `DELIVERY-PLAN.md` | Phases, milestones, critical path, dependencies, risks | Lead, PM, stakeholders |
| `BACKLOG.md` | Seven epics, stories with acceptance criteria | Team, planning |
| `INTERFACE-CONTRACTS.md` | Seams between components; agree before splitting work | Engineers |
| `VERIFICATION-MATRIX.md` | Assumptions to confirm before building on them | Whoever takes E1-S2 |
| `TEST-STRATEGY.md` | Levels, invariant tests, fixture approach | Engineers, QA |
| `NFRS.md` | Volume, performance, availability, retention, observability | Lead, platform |
| `RUNBOOK.md` | Failure modes and response | On-call, ops |
| `ENGINEERING-STANDARDS.md` | Definition of done, controlled config, invariants in code | Engineers, reviewers |

## Read in this order

1. `DELIVERY-PLAN.md` — shape and sequence
2. `VERIFICATION-MATRIX.md` — what we do not yet know
3. `INTERFACE-CONTRACTS.md` — agree before splitting work
4. `BACKLOG.md` — the work itself

## The two things to carry into every decision

**Absence of data is never evidence of remediation.** Most of the unusual
design choices follow from this one line.

**Vulnerability identity must be independent of asset identity.** Our
assets are rebuilt and inherit new identifiers. Any design that keys
findings to assets produces confident, wrong numbers.
