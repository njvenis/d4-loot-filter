# Test strategy

## Principle

This system's failure mode is not a crash. It is producing confident,
plausible, wrong numbers. Conventional coverage does not catch that.
Testing must therefore target the invariants, not just the code paths.

## Levels

**Unit.** Identity resolver rule matching, circuit breaker threshold
arithmetic, hash input construction, ledger state transitions. Fast, no
external dependencies, run on every commit.

**Contract.** Each component tested against the interfaces in
`INTERFACE-CONTRACTS.md` with the others stubbed. Enables parallel work.
Both identity resolver implementations must pass one shared suite.

**Integration.** Against a disposable DefectDojo instance with fixture
scan files. No live scanner credentials in CI.

**Invariant.** The tests below. These are the ones that matter.

**Load.** Ingest and bulk operations at projected volume plus headroom.
Establishes whether UI and automation remain usable — not a formality,
since finding volume is the parameter most likely to be underestimated.

## Invariant tests

Each maps to a design decision. Failure of any is a release blocker.

| ID | Test | Asserts |
|---|---|---|
| I1 | Rebuild continuity | Same vuln on a rebuilt instance produces one continuous finding, not two |
| I2 | Detection date durability | First-detection date unchanged across rebuild and reactivation |
| I3 | Override survival | Manual downgrade persists through reimport and through rebuild |
| I4 | No closure without assessment | A finding on an unassessed service never changes state |
| I5 | No closure on absence alone | Absence from a scan of a *different* service closes nothing |
| I6 | Circuit breaker engages | A scan missing most findings is held, not submitted |
| I7 | Claim is not closure | GitHub issue closure leaves finding state unchanged |
| I8 | Contradiction reopens | Issue reopens when a scan shows the vulnerability still present |
| I9 | Unresolved is not dropped | An occurrence matching no rule appears in the unresolved queue |
| I10 | Import path absent | No code path reaches `import-scan`; enforced by static check |
| I11 | Idempotent sync | Re-running the sync worker against unchanged state produces no writes |
| I12 | Recurrence counted | Reactivation increments the counter without altering detection date |

## Fixture approach

Build fixtures from real exports with identifiers substituted. A rebuild
fixture is the same export with instance identifiers changed and nothing
else — which is precisely what a rebuild looks like to a scanner.

Keep fixtures in version control. Do not generate them synthetically;
real scanner output contains structural quirks that synthetic data misses,
and those quirks are where parsers break.

## What we deliberately do not test

Third-party parser correctness. If DefectDojo's Qualys parser has a bug,
that is an upstream issue, not ours to duplicate in tests. We test that we
call it correctly and handle its output correctly.

## Test data handling

Scanner exports contain live vulnerability detail for real infrastructure.
Fixtures must be treated at the same classification as the scanner console
itself. Redact where possible; restrict repository access where not.
