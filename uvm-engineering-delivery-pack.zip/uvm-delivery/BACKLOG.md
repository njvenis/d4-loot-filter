# UVM — Delivery backlog

Seven epics, sequenced. Each epic is independently demonstrable. Stories
carry acceptance criteria written so QA can verify them without asking the
author what was meant.

Estimates are relative points, not days. Team to recalibrate at planning.

---

## E1 — Platform foundation

**Goal:** DefectDojo running, reachable, with identity configuration applied
and verified against the deployed version.

**Demonstrable at end:** a scan report imported by hand produces findings
with the expected hash behaviour.

### E1-S1 — Stand up DefectDojo locally (3)
Deploy DefectDojo via Compose with a pinned version tag.

*Acceptance:*
- Version is pinned in config, not `latest`
- Admin account created; API token issued and stored in the team secret store
- Health endpoint returns 200 from another container on the network
- Teardown and rebuild reproduces the same state from config alone

### E1-S2 — Verify DefectDojo behavioural assumptions (5)
The design assumes specific DefectDojo behaviour. Confirm each against the
deployed version **before** dependent work starts. Findings recorded in the
verification matrix (see `VERIFICATION-MATRIX.md`).

*Acceptance:*
- Each assumption in the matrix marked confirmed, refuted, or version-dependent
- Any refuted assumption raised as a blocker with proposed design change
- Exact parser name strings recorded as the deployed version reports them
- `settings.dist.py` field names captured for the deployed version

*Note:* this story exists because the design was written against
documentation, not against a running instance. Treat refutation as a normal
outcome, not a failure.

### E1-S3 — Apply and document identity configuration (5)
Configure deduplication per the identity model.

*Acceptance:*
- Hash algorithm set to hash_code for both parsers
- Hash fields exclude every ephemeral identifier listed in the design
- Endpoint fields excluded from dedup
- Configuration held in version control; changes require review
- A written note in the repo explains why each field is present or absent

### E1-S4 — Sidecar state schema (2)
*Acceptance:*
- Schema applied via migration tooling, not manual SQL
- Rollback tested
- Per-component database roles created; no component uses a superuser

---

## E2 — Ingest

**Goal:** scan data flows in reliably, with identity resolved.

**Demonstrable at end:** a scheduled run ingests both sources and findings
appear correctly attributed to logical services.

### E2-S1 — File-based ingest path (3)
Ingest from exported report files before any live API work.

*Acceptance:*
- Given a Qualys XML export, when ingest runs, findings appear on the
  expected Test
- Given a Sysdig JSON export, same
- Submission uses reimport only; no code path calls import
- `close_old_findings` is false and not parameterised

### E2-S2 — Identity resolver behind an interface (8)
*Acceptance:*
- Resolver is an interface with a static-map implementation for now
- Given an occurrence with a service tag, resolver returns that service
- Given an occurrence matching no rule, resolver returns unresolved — it
  does not guess
- Resolution reason recorded for audit
- Swapping implementation requires no change to calling code
- Unit tested against a fixture set including edge cases: missing tags,
  conflicting rules, empty values

### E2-S3 — Stable Test registry (3)
*Acceptance:*
- Given a (source, service) pair not seen before, a Test is created once
  and its ID persisted
- Given a pair seen before, the persisted ID is reused
- Concurrent runs cannot create duplicate Tests for the same pair
- Registry survives service restart

### E2-S4 — Unresolved queue (3)
*Acceptance:*
- Unresolved findings are submitted to a dedicated product, visible in the UI
- They are never silently dropped
- Count is exposed as a metric
- An operator can see which rule set failed and why

### E2-S5 — Circuit breaker (5)
*Acceptance:*
- Given an incoming scan that would leave more than the configured
  percentage of active findings unmatched, submission is held and an alert
  raised
- Threshold is configurable but has a safe default
- A held run can be inspected and released by an operator, and that release
  is audited
- Breaker state is observable in monitoring
- Unit tested with synthetic scans at, below, and above threshold

### E2-S6 — Sysdig API adapter (5)
### E2-S7 — Qualys API adapter (8)
*Note on sizing:* Qualys is larger due to asynchronous report generation
(launch, poll, retrieve), XML parsing, and pagination. Do not start it until
identity and dedup are proven.

*Acceptance (both):*
- Credentials read from the secret store, never from source
- Transient failures retried with backoff; permanent failures alert
- Partial retrieval never submitted as a complete scan
- Rate limits respected
- Integration tested against a recorded fixture, not live, in CI

### E2-S8 — Scheduling (2)
*Acceptance:*
- Runs on a configurable schedule
- Overlapping runs prevented
- Run outcome (success, held, failed) recorded and alertable

---

## E3 — Reconciliation and closure

**Goal:** findings close only on evidence; unscanned services are visible.

### E3-S1 — Assessment tracking (3)
*Acceptance:*
- Every completed ingest records last-assessed per (service, source)
- Partial or failed ingest does not update it
- Query exposes services by staleness

### E3-S2 — Positive-confirmation closure (8)
*Acceptance:*
- Given a service assessed this cycle and a finding absent from that scan,
  the finding closes with mitigation timestamp set to scan time
- Given a service not assessed this cycle, no finding on that service
  changes state
- No other component closes findings
- Closure is audited with the evidencing scan referenced

### E3-S3 — Staleness watchdog (3)
*Acceptance:*
- A service unassessed beyond threshold raises a finding of its own
- Threshold configurable
- Alert fires once per service per breach, not per run

### E3-S4 — Recurrence tracking (3)
*Acceptance:*
- A finding transitioning from mitigated back to active increments a
  recurrence counter
- Counter is queryable for reporting
- Original detection date is unchanged by recurrence

---

## E4 — Ownership and GitHub sync

### E4-S1 — Owner resolution (5)
*Acceptance:*
- Service resolves to a repository and assignee
- Unresolvable ownership routes to a default queue and is reported
- Resolution source is recorded per finding

### E4-S2 — Issue creation (5)
*Acceptance:*
- One issue per (service, CVE); never per instance
- Issue body renders from a template with finding detail and remediation
  guidance
- GitHub App authentication; no personal access tokens anywhere
- Dry-run mode is the default; live mode requires explicit configuration

### E4-S3 — Rate limiting and batching (3)
*Acceptance:*
- Primary and secondary rate limits respected
- Backoff on 403/429 with retry-after honoured
- A large first run cannot exhaust quota or flood a repository

### E4-S4 — Claim handling (5)
*Acceptance:*
- Given an issue closed in GitHub, the linked finding does not change state
- The closure is recorded as an unconfirmed claim
- Given a subsequent scan confirming absence, both finding and issue close
  with an evidence comment
- Given a subsequent scan showing the vulnerability still present, the issue
  reopens with a discrepancy comment
- Reopened issues are counted and reportable

### E4-S5 — Issue reconciliation on restart (3)
*Acceptance:*
- Restarting the worker does not duplicate existing issues
- Orphaned ledger entries (issue deleted in GitHub) are detected and reported

---

## E5 — Reporting

### E5-S1 — Read-only reporting role (2)
### E5-S2 — Core metric views (5)
*Acceptance:*
- Age calculated from first-ever detection, not current record age
- MTTR calculated only on positively confirmed closures
- Assessment coverage and ownership coverage exposed
- Recurrence distribution available
- Each metric has a written definition in the repo

### E5-S3 — Dashboards (3)
*Acceptance:*
- Executive view: posture, trend, coverage
- Engineering view: scoped to owned services
- No dashboard can write to the database

---

## E6 — Operational readiness

### E6-S1 — Structured logging and correlation IDs (3)
### E6-S2 — Alerting (5)
*Acceptance:*
- Alerts exist for: ingest failure, breaker trip, staleness breach, sync
  failure, rate-limit exhaustion, reconciler failure
- Each alert maps to a runbook entry
- Alert fatigue considered: no alert fires more than once per condition per
  cycle

### E6-S3 — Backup and restore (5)
*Acceptance:*
- Findings history is backed up on a defined schedule
- **Restore is tested, not assumed** — a restore into a clean environment is
  performed and documented
- Recovery point and recovery time recorded

### E6-S4 — Runbook (3)
### E6-S5 — Access model (5)
*Acceptance:*
- Roles distinguish view, edit, override severity, accept risk, administer
- A user without override permission cannot override; the attempt is logged
- Read-only role exists for audit

---

## E7 — Production migration

### E7-S1 — Containerisation review (2)
### E7-S2 — Infrastructure provisioning (8)
### E7-S3 — Secret migration (3)
### E7-S4 — SSO integration (5)
### E7-S5 — Network controls (5)
*Acceptance:*
- Egress restricted to the three required destinations
- No inbound path from the internet
- The four deliberately-closed paths in the design are verified closed
- Evidence captured for security review

### E7-S6 — Cutover and parallel run (5)
*Acceptance:*
- Local and production run in parallel for an agreed period
- Finding counts reconcile between them
- Rollback plan documented and viable

---

## Sequencing constraints

- E1-S2 blocks all of E2. The design assumes behaviour we have not yet
  verified.
- E2-S2 blocks E2-S6 and E2-S7. Prove identity before writing adapters.
- E2 must be stable before E3; closure logic against unstable identity is
  untestable.
- E4-S4 depends on E3-S2. The claim model needs a working confirmation path.
- E7 should not start until E1–E6 are demonstrably complete locally.

## Out of scope for this delivery

Application security findings (SAST/DAST/SCA), replacement of the existing
SecOps pipeline, multi-region resilience, and any LLM-assisted feature
beyond advisory issue text.
