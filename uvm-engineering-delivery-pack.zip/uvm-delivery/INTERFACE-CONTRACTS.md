# Interface contracts

Defines the seams between components so they can be built in parallel and
tested independently. Agree these before implementation starts; changing
them mid-delivery costs more than getting them approximately right now.

Notation is illustrative. Language and serialisation are the team's call —
what matters is the shape and the guarantees.

---

## 1. Feeder → DefectDojo

**Direction:** outbound HTTP, feeder initiates.

**Contract:**
- Only `POST /api/v2/reimport-scan/` is permitted. The feeder must contain
  no code path capable of calling `import-scan`.
- `close_old_findings` is always false. Not a parameter, not configurable.
- `service` must be populated with a resolved logical service key, or the
  submission must target the unresolved product.
- `test` must be an ID retrieved from the Test registry, never created
  inline per run.

**Guarantee the feeder makes:** a submission represents a complete scan of
the named service by the named source. Partial retrievals are never
submitted.

**Guarantee DefectDojo makes:** matching is deterministic given the same
hash configuration. (Verify in E1-S2 — this is an assumption until proven.)

---

## 2. Identity resolver

**Consumed by:** feeder only.

```
resolve(occurrence) -> Resolution

occurrence:
  source          enum(qualys, sysdig)
  instance_ref    string    # forensic only, must not influence identity
  image_repo      string?   # repository path, digest excluded
  tags            map<string,string>

Resolution:
  status          enum(resolved, unresolved)
  service         string?   # populated iff resolved
  matched_by      string?   # rule identifier, for audit
```

**Contract:**
- Deterministic: same input always yields the same output.
- No network calls in the hot path beyond a cached lookup.
- `unresolved` is a valid, expected outcome. The resolver must never guess.
- Implementations are swappable. The static-map implementation and the
  future tag-API implementation must satisfy the same test suite.

**Why an interface:** the POC uses a static file; production reads live tag
data. Everything downstream must be indifferent to which is in use.

---

## 3. Feeder state store

**Owned by:** feeder. **Read by:** reconciler (assessment log only).

```
test_registry(source, service) -> (product_id, test_id)
  - insert-once semantics; concurrent runs must not create duplicates
  - never deleted while findings reference the Test

assessment_log(service, source, run_id) -> (completed_at, finding_count)
  - written only on successful, complete ingest
  - a held or failed run writes nothing
```

**Contract:** the reconciler reads `assessment_log` and treats its absence
as "not assessed". The feeder must therefore never write a row for an
incomplete run — a false row here produces a false closure downstream.

This is the highest-consequence contract in the system.

---

## 4. Reconciler → DefectDojo

**Contract:**
- The reconciler is the only component permitted to transition a finding to
  mitigated.
- Closure requires an `assessment_log` row for the finding's service and
  source, dated within the current cycle, and absence of the finding's hash
  from that assessment.
- Every closure writes an audit record referencing the evidencing run ID.

**Explicitly forbidden:** closing on a schedule, closing on age, closing on
issue state, closing on absence without an assessment record.

---

## 5. Reconciler → sync worker

**Mechanism:** the issue ledger table. No direct calls.

```
issue_ledger(service, cve) -> (repo, issue_number, state, claimed_at, confirmed_at)
  state: open | claimed | closed
```

**Transitions and who owns them:**

| From | To | Owner | Trigger |
|---|---|---|---|
| — | open | sync worker | issue created |
| open | claimed | sync worker | GitHub closure detected |
| claimed | closed | reconciler | scan confirms absence |
| claimed | open | reconciler | scan shows still present |
| open | closed | reconciler | scan confirms absence |

**Contract:** the sync worker never writes `closed`. The reconciler never
writes `open` on creation. Each transition is one component's
responsibility; overlapping ownership here produces race conditions that
present as flapping issues.

---

## 6. Sync worker → GitHub

**Contract:**
- Authentication is a GitHub App installation token, derived from a JWT.
  Personal access tokens are prohibited.
- Scope is least-privilege: issues read/write on target repositories only.
- All writes pass through a rate guard honouring primary and secondary
  limits and `Retry-After`.
- Dry-run is the default mode. Live mode is explicit configuration.
- Idempotent: re-running against unchanged state produces no writes.

**Guarantee:** an issue is created at most once per (service, CVE). The
ledger is authoritative; GitHub is a projection.

---

## 7. Reporting → database

**Contract:**
- Read-only role. `SELECT` on views only; no table access, no write grants.
- Reporting never calls the DefectDojo API.
- Metric definitions live in version control alongside the view
  definitions. A metric without a written definition is not published.

---

## Cross-cutting

**Audit.** Every component writes an audit row for every state change it
causes, with component name as actor. DefectDojo's own audit log covers
in-app human actions; ours covers machine actions. Both are required.

**Configuration.** Environment variables only. No configuration file baked
into an image. This is what makes local-to-production migration cheap.

**Failure.** No component may treat an upstream failure as an empty result.
An empty scan and a failed scan are different things, and conflating them
is the primary way this system could silently under-report.
