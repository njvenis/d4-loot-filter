# DefectDojo verification matrix

The design was written against documentation. These assumptions must be
confirmed against the deployed version before dependent work proceeds
(story E1-S2). Refutation is a normal outcome — record it and adjust.

Fill `Result` with: CONFIRMED / REFUTED / VERSION-DEPENDENT, plus the
version tested and a link to evidence.

| # | Assumption | How to verify | Blocks | Result |
|---|---|---|---|---|
| V1 | `reimport-scan` matches findings to an existing Test rather than creating a new one | Import once, reimport identical file, confirm one Test and one finding | All of E2 | |
| V2 | Hash fields are configurable per parser and take effect without a rebuild | Set config, restart, import, inspect `hash_code` | E1-S3 | |
| V3 | `service` is appended to the hash by default | Import two identical findings with different service values; confirm two findings | Identity model | |
| V4 | Endpoint data can be excluded from dedup entirely | Set endpoint fields empty; import same vuln on two hostnames; confirm one finding | Identity model | |
| V5 | Finding `date` (first detection) survives reimport, mitigation, and reactivation | Import, mitigate, reimport with vuln present, inspect date | Age and MTTR metrics | |
| V6 | A manual severity override survives reimport | Override, reimport, inspect severity | Core requirement | |
| V7 | A risk acceptance survives reactivation after a gap | Accept, mitigate, reactivate, inspect acceptance | Override model | |
| V8 | `close_old_findings=false` prevents all automatic closure | Reimport a scan missing a previously-seen finding; confirm it stays active | Closure model | |
| V9 | Cross-tool dedup (Qualys + Sysdig, same CVE, same service) converges to one finding in the open-source edition | Import matched pair, inspect finding count | Licence decision | |
| V10 | Exact parser name strings as the deployed version reports them | Read parser list from the running instance | E1-S3 config | |
| V11 | Hash field names available per parser | Inspect `settings.dist.py` for the deployed version | E1-S3 config | |
| V12 | API supports the finding state transitions the reconciler needs | Attempt mitigation via API, inspect result | E3-S2 | |
| V13 | Audit log records API-driven changes with attributable actor | Make an API change, inspect audit log | Audit requirement | |
| V14 | Bulk operations perform acceptably at our finding volume | Load test with representative volume | Usability | |

## If V9 is refuted

Cross-tool convergence requiring the paid tier changes the commercial
picture but not the architecture. Options, in preference order:

1. Accept per-scanner findings and deduplicate in reporting only. Cheapest;
   loses single-pane triage.
2. Normalise Qualys QIDs to CVEs in the feeder so both scanners emit
   compatible hash inputs. Moves the problem into code we own.
3. Purchase the tier.

Decide before E2-S7, since it affects how the Qualys adapter shapes output.

## If V5 or V6 is refuted

Escalate immediately. These underpin the two requirements that justified
the project. A refutation here means either a different core product or a
significant design change, and it is better found in week one.
