# Operational runbook

Each entry: symptoms, causes, diagnosis, resolution, escalation. Entries
marked **do not resolve by disabling** must never be closed by turning off
the control that surfaced the problem.

---

## R1 — Ingest failure, single source

**Symptoms:** alert on feed failure; one source shows a stale
last-assessed across all services.

**Likely causes:** expired credential, scanner API outage, network egress
change, scanner-side rate limiting.

**Diagnosis:** check component logs for HTTP status; confirm credential
validity against the scanner console; confirm egress allow-list unchanged.

**Resolution:** restore credential or connectivity. The system self-heals
on the next successful run — no manual finding manipulation required.

**Important:** findings from the affected source will move to NOT ASSESSED
and their SLA clocks pause. This is correct behaviour. Do not manually
close or reactivate them.

**Escalation:** if unresolved beyond 48 h, the staleness watchdog will
begin raising findings. Notify security lead — coverage is degraded and
reporting should be caveated.

---

## R2 — Circuit breaker trip

**Symptoms:** submission held; alert raised naming the Test and percentage.

**Meaning:** an incoming scan contained substantially fewer findings than
the active set. Either a large genuine remediation, or an incomplete scan.

**Diagnosis:**
1. Check the scan's asset coverage against the previous run
2. Check for scanner-side errors or a changed scan scope
3. Check whether a large patching exercise genuinely occurred

**Resolution:** if the scan is genuinely complete, release the held run —
this is audited. If incomplete, discard and re-run the source.

**Do not resolve by disabling.** Raising the threshold to clear an alert
converts this control into decoration. If the threshold is genuinely
mistuned, change it deliberately, with review, and record why.

**Escalation:** repeated trips on the same source indicate scan
instability. Raise with the scanning team.

---

## R3 — Staleness alert

**Symptoms:** finding raised against a service unassessed beyond threshold.

**Likely causes:** service decommissioned but still in the registry; scan
scope excludes it; tagging changed so occurrences no longer resolve to it;
agent not installed on rebuilt instances.

**Diagnosis:** confirm the service still exists; check whether occurrences
are arriving under a different service key or in the unresolved queue.

**Resolution:** correct scan scope or tagging. If genuinely
decommissioned, retire the service in the registry — do not delete the Test
while findings reference it.

**Note:** the last cause is the interesting one. A rebuild pipeline that
omits the scanner agent produces assets that look clean because they are
invisible. Treat repeated staleness on rebuilt services as a pipeline
defect.

---

## R4 — GitHub rate limit exhaustion

**Symptoms:** sync failures with 403/429; issues not created or updated.

**Likely causes:** large first run; a bulk finding change generating mass
updates; another integration sharing the App installation.

**Diagnosis:** check remaining quota and reset window; check volume of
pending writes.

**Resolution:** the rate guard should back off automatically. If it did
not, that is a defect — raise it. Reduce batch size; stagger the first run
against an existing backlog.

**Escalation:** if quota is shared with other automation, coordinate.

---

## R5 — Duplicate issues

**Symptoms:** multiple issues for the same service and CVE.

**Likely causes:** ledger write failed after issue creation; concurrent
sync runs; ledger restored from backup behind GitHub state.

**Diagnosis:** inspect the ledger for the affected pair; check for
overlapping run windows.

**Resolution:** close duplicates manually, retaining the earliest;
reconcile the ledger. Then find the root cause — duplicates are a symptom
of a ledger integrity problem, and closing them without diagnosis
guarantees recurrence.

---

## R6 — Findings duplicating or wrongly merging

**Symptoms:** the same vulnerability appearing as multiple findings, or
distinct vulnerabilities merged into one.

**Likely causes:** hash configuration changed; parser version change
altering field population; service key inconsistently applied.

**Diagnosis:** inspect hash values on affected findings; check
configuration history; check whether the service field is populated
consistently.

**Resolution:** correct configuration. Note that changing hash
configuration does not retroactively re-key existing findings — a
remediation plan for the affected set is required, and this may mean
accepting a discontinuity in historical metrics.

**Escalation:** always. This affects data integrity and therefore
reporting validity. Any period affected must be caveated in reports.

**Do not resolve by disabling** deduplication.

---

## R7 — DefectDojo unavailable

**Symptoms:** all components failing; UI unreachable.

**Resolution:** standard service recovery. Components should back off and
retry rather than failing permanently.

**Important:** on recovery, verify that no component submitted partial data
during the outage. Check the assessment log for rows written by runs that
did not complete — a false assessment row is the one artefact of an outage
that can cause a false closure later.

---

## R8 — Suspected under-reporting

**Symptoms:** finding counts fall unexpectedly; a service shows no findings
where it previously had many; MTTR improves suddenly.

**This is the failure mode that matters most.** Treat any unexplained
improvement in vulnerability metrics as a suspected defect until proven
otherwise.

**Diagnosis:**
1. Confirm assessment coverage — are services actually being scanned?
2. Check the unresolved queue — has tagging changed, routing findings away?
3. Check for closures without evidencing scans in the audit log
4. Compare finding counts against the scanner consoles directly

**Escalation:** security lead immediately. Reporting for the affected
period should be withheld until explained.
