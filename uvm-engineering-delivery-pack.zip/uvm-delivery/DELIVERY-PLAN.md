# Delivery plan

## Shape

Seven epics across three phases. Each phase ends with something
demonstrable, and each is a legitimate stopping point if priorities change.

| Phase | Epics | Outcome | Stop-here value |
|---|---|---|---|
| 1 — Prove | E1, E2 | Findings ingest with stable identity across rebuilds | Answers whether the design works; produces volume and coverage numbers |
| 2 — Operate | E3, E4, E5 | Full loop with reporting | Usable internally by the security team |
| 3 — Productionise | E6, E7 | Deployed, monitored, access-controlled | Suitable as a system of record |

Phase 1 is deliberately the riskiest work. If the design is wrong, it is
wrong at E1-S2 or E2-S2, and finding that out costs two weeks rather than
a quarter.

## Critical path

```
E1-S2 (verify assumptions)
  └─> E1-S3 (identity config)
        └─> E2-S2 (identity resolver)
              └─> E2-S1 (file ingest) ──> E2-S6/S7 (adapters)
                    └─> E3-S2 (closure)
                          └─> E4-S4 (claim handling)
```

Everything else parallelises around this.

## Parallelisation

Once `INTERFACE-CONTRACTS.md` is agreed, three streams can run
concurrently:

- Feeder and identity (the critical path)
- Sync worker against a stubbed ledger and a throwaway repository
- Reporting views against seeded data

The contracts document exists to make this possible. Agree it before
splitting the work.

## Milestones

| M | Gate | Evidence |
|---|---|---|
| M1 | Assumptions verified | Verification matrix complete; any refutation resolved |
| M2 | Identity proven | Invariant tests I1, I2, I3 passing against real fixture data |
| M3 | Ingest live | Both adapters running on schedule; circuit breaker demonstrated |
| M4 | Closure correct | Invariant tests I4, I5, I6 passing |
| M5 | Loop closed | Invariant tests I7, I8 passing; issues created in a test repository |
| M6 | Reporting | Metrics published with written definitions |
| M7 | Production ready | Access model, alerting, tested restore, network controls verified |

M2 is the real go/no-go. If identity does not hold across rebuilds, neither
this build nor any vendor product solves the underlying problem, and the
conversation changes to tagging remediation first.

## Dependencies on other teams

| Need | From | When | Risk if late |
|---|---|---|---|
| Confirmation of service tagging coverage | Platform | Before E2-S2 | Blocks the critical path entirely |
| Scanner API credentials, read-only | Security ops | Before E2-S6 | Delays adapters; file ingest unblocks earlier work |
| Test GitHub organisation or repository | Platform | Before E4 | Sync work cannot start |
| GitHub App registration and approval | Platform / GitHub admin | Before E4-S2 | Blocks live sync |
| Decision on risk acceptance authority | Security leadership | Before E6-S5 | Blocks access model |
| Cloud account and network approval | Platform | Before E7 | Blocks phase 3 only |

## Principal risks

| Risk | Impact | Mitigation |
|---|---|---|
| Service tagging is incomplete | Ownership resolution fails; the design's core dependency is unmet | Measure coverage in phase 1 before building on it. A tagging remediation project may need to precede this one. |
| A verification assumption is refuted | Design change mid-build | Front-loaded as E1-S2; refutation in week one is cheap |
| Cross-tool dedup requires paid tier | Commercial decision, not architectural | Fallback options documented in the verification matrix |
| Finding volume exceeds expectation | Performance and issue-volume problems | Measure in phase 1; NFR targets set against measured values |
| Key person concentration | The system becomes unmaintainable if one person leaves | Interface contracts, documented invariants, mandatory second reviewer |

That last risk deserves stating plainly in a governance context: a
compliance-bearing control understood by one person is itself an audit
finding. The documentation in this pack is partly a mitigation for it.

## What would make us stop

- Tagging coverage below a threshold that makes ownership resolution
  unviable — remediate tagging first
- Verification refuting the identity or override assumptions — reassess
  core product choice
- Measured volume implying infrastructure cost comparable to a commercial
  licence — revisit build versus buy with real numbers

Each of these is a legitimate outcome of phase 1, not a failure of it.
Phase 1 exists to produce these answers.
