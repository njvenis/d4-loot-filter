# Engineering standards

Project-specific standards. Assumes the team's general conventions apply
for language, style, and review; this covers what is particular to a
system whose output is used as compliance evidence.

## Definition of done

A story is done when:
- Acceptance criteria demonstrably met
- Unit and contract tests written and passing
- Any invariant test the story touches still passes
- Configuration changes are in version control, not applied by hand
- Audit records written for any new state change
- Failure mode documented — what breaks, whether it is silent, how it is
  detected
- Runbook updated if a new alert or failure mode was introduced
- Reviewed by someone who did not write it

That last point is not a formality here. This system produces evidence
used in assurance and regulatory contexts. Single-author code in that
position is a concentration risk regardless of quality.

## Controlled configuration

The following are **controlled**: changes require review by security, not
only by engineering, and the reason must be recorded.

- Deduplication algorithm and hash field configuration
- Circuit breaker threshold
- Staleness threshold
- SLA definitions
- Anything that determines what counts as the same vulnerability, or as a
  remediated one

Treat a change to these as equivalent to a firewall rule change. They are
not tuning parameters.

## Invariants in code

Where an invariant can be enforced structurally rather than by convention,
enforce it structurally:

- No function exists that calls `import-scan`
- `close_old_findings` is a literal, not a parameter
- Closure is only reachable from the reconciler
- The identity resolver has no fallback branch that guesses

A static check in CI should fail the build if `import-scan` appears
anywhere in the codebase.

## Audit

Every state change writes an audit record: timestamp, component, action,
subject, before and after values where applicable. Machine actions are
attributable to the component; human actions carry the user.

Audit writes are not optional and not conditional on log level.

## Failure handling

- An upstream failure is never treated as an empty result.
- A partial result is never treated as complete.
- Retries use backoff and have a bound; exhaustion alerts rather than
  silently continuing.
- No component logs a failure and proceeds as though it succeeded.

## Secrets

- Never in source, never in images, never in logs.
- POC may use a gitignored environment file; production uses the managed
  store. The gitignore entry is the first commit, not a later one.
- The GitHub App private key is the highest-value credential in this
  system. Treat its handling accordingly.

## Metrics

A metric is not published until its definition is written down and
reviewed. "Age" and "MTTR" in particular have several defensible
definitions, and the one in use must be stated wherever the figure appears.

## Dependencies

Pin versions, including the DefectDojo image tag. This system's behaviour
depends on upstream implementation details that documentation does not
fully specify; an unpinned upgrade can change deduplication behaviour
without any change on our side.

Upgrades are a planned activity with re-verification against
`VERIFICATION-MATRIX.md`, not a routine patch.
